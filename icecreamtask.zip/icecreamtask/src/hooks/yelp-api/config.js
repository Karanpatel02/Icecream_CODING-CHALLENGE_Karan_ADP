export const API_BASE_URL = 'https://api.yelp.com/v3';

export const BEARER_TOKEN = '';