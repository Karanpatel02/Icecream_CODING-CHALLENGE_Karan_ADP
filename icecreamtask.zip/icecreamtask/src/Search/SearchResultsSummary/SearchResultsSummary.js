import React from 'react';
import styles from './SearchResultsSummary.module.css';

export const SearchResultsSummary=(props)=> {
    const {amountResults, term, shownResults, location} = props;
    let resultStats = null;
    if (amountResults && shownResults) {
        resultStats = <p>Showing 1-{shownResults} out of {amountResults} results</p>
    }
    return (
        <div className={styles.container}>
            <div className={styles['search-summary']}>
                <h1 className='subtitle'><strong>{term}</strong> {location}</h1>
                {resultStats}
            </div>
        </div>
    );
}